import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_FILE = path.join(__dirname, "data.json");

const DEFAULT_DATA = {
  tickets: [],
  investments: [],
  users: {},
  pool: null,
  poolHistory: [],
  ticketMessageId: null,
};

export function loadData() {
  try {
    if (!fs.existsSync(DATA_FILE)) {
      saveData(DEFAULT_DATA);
      return { ...DEFAULT_DATA };
    }
    const raw = fs.readFileSync(DATA_FILE, "utf-8");
    return JSON.parse(raw);
  } catch (err) {
    console.error("Failed to load data.json, using defaults:", err);
    return { ...DEFAULT_DATA };
  }
}

export function saveData(data) {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to save data.json:", err);
  }
}

let _data = loadData();

export function getData() {
  return _data;
}

export function mutateData(fn) {
  fn(_data);
  saveData(_data);
}
