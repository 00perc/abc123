import "dotenv/config";
import {
  Client,
  GatewayIntentBits,
  Partials,
  REST,
  Routes,
  Events,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
} from "discord.js";
import express from "express";
import { getData, mutateData } from "./data.js";
import { createTicket, restoreTicketTimers } from "./tickets.js";
import { startPolling } from "./poller.js";
import { commandDefinitions, handleCommand } from "./commands.js";
import { CHANNEL_TICKET_BUTTON } from "./constants.js";

const token = process.env["DISCORD_TOKEN"];
const guildId = process.env["GUILD_ID"];

if (!token || !guildId) {
  throw new Error("DISCORD_TOKEN and GUILD_ID are required environment variables");
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages,
  ],
  partials: [Partials.Channel, Partials.Message],
});

async function registerCommands() {
  const rest = new REST({ version: "10" }).setToken(token);
  await rest.put(Routes.applicationGuildCommands(client.user.id, guildId), {
    body: commandDefinitions,
  });
  console.log("Slash commands registered.");
}

async function ensureTicketMessage(guild) {
  let channel = guild.channels.cache.get(CHANNEL_TICKET_BUTTON);
  if (!channel) {
    try {
      channel = await guild.channels.fetch(CHANNEL_TICKET_BUTTON);
    } catch (err) {
      console.error(
        `Cannot access ticket button channel ${CHANNEL_TICKET_BUTTON}. ` +
        `Guild: ${guild.name} (${guild.id}). Error:`, err
      );
      return;
    }
  }

  const data = getData();

  if (data.ticketMessageId) {
    try {
      const existing = await channel.messages.fetch(data.ticketMessageId);
      if (existing) {
        console.log("Reusing existing ticket message:", data.ticketMessageId);
        return;
      }
    } catch {
      console.log("Existing ticket message not found, sending new one.");
    }
  }

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("create_ticket")
      .setLabel("Create Ticket")
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId("create_support")
      .setLabel("Support")
      .setStyle(ButtonStyle.Secondary)
  );

  const embed = new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle("Investment & Support")
    .setDescription(
      "**Create Ticket** — Open a private investment ticket with a unique Solana wallet.\n\n**Support** — Contact the team with questions or issues."
    )
    .setTimestamp();

  const msg = await channel.send({ embeds: [embed], components: [row] });
  mutateData((d) => {
    d.ticketMessageId = msg.id;
  });
  console.log("Sent new ticket message:", msg.id);
}

client.once(Events.ClientReady, async (readyClient) => {
  console.log(`Bot logged in as ${readyClient.user.tag}`);
  await registerCommands();

  const guild =
    readyClient.guilds.cache.get(guildId) ??
    (await readyClient.guilds.fetch(guildId).catch(() => null));
  if (!guild) {
    console.error("Guild not found:", guildId);
    return;
  }

  await guild.channels.fetch().catch(console.error);
  await guild.members.fetch().catch(console.error);

  await ensureTicketMessage(guild);
  restoreTicketTimers(client, guild);
  startPolling(client, guild);
});

client.on(Events.InteractionCreate, async (interaction) => {
  const guild = interaction.guild;
  if (!guild) return;

  if (interaction.isButton()) {
    await handleButton(interaction, guild);
    return;
  }

  if (interaction.isChatInputCommand()) {
    await handleCommand(interaction, client, guild);
    return;
  }
});

async function handleButton(interaction, guild) {
  const { customId, user } = interaction;

  if (customId === "create_ticket" || customId === "create_support") {
    await interaction.deferReply({ ephemeral: true });
    const ticketType = customId === "create_ticket" ? "ticket" : "support";

    try {
      const { channel, alreadyExists } = await createTicket(
        client,
        guild,
        user.id,
        user.username,
        ticketType
      );

      if (alreadyExists) {
        await interaction.editReply({
          embeds: [
            new EmbedBuilder()
              .setColor(0xfee75c)
              .setDescription(
                `You already have an open ticket: <#${channel.id}>. Please use it or wait for it to close.`
              ),
          ],
        });
        return;
      }

      await interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor(0x57f287)
            .setDescription(`Your ticket has been created: <#${channel.id}>`),
        ],
      });
    } catch (err) {
      console.error("Failed to create ticket:", err);
      await interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor(0xed4245)
            .setDescription("Failed to create your ticket. Please try again later."),
        ],
      });
    }
    return;
  }
}

client.on(Events.ChannelDelete, async (channel) => {
  if (!channel.isTextBased()) return;
  const data = getData();
  const ticket = data.tickets.find((t) => t.channelId === channel.id && t.status === "open");
  if (ticket) {
    mutateData((d) => {
      const t = d.tickets.find((t) => t.channelId === channel.id);
      if (t && t.status === "open") t.status = "closed";
    });
  }
});

client.login(token).catch((err) => {
  console.error("Failed to login:", err);
  process.exit(1);
});

const keepAlive = express();
keepAlive.get("/", (_req, res) => res.send("Bot is running"));
const keepAlivePort = parseInt(process.env["PORT"] ?? "3000", 10);
keepAlive.listen(keepAlivePort, () => {
  console.log(`Keep-alive server running on port ${keepAlivePort}`);
});
