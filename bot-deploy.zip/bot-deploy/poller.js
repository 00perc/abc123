import { getData, mutateData } from "./data.js";
import { getIncomingTransactions } from "./wallet.js";
import { handlePayment } from "./payments.js";
import { POLL_INTERVAL_MS } from "./constants.js";

const lastSeenSig = {};

export function startPolling(client, guild) {
  setInterval(() => {
    pollAll(client, guild).catch(console.error);
  }, POLL_INTERVAL_MS);
}

async function pollAll(client, guild) {
  const data = getData();
  const openTickets = data.tickets.filter(
    (t) => t.status === "open" && !t.paymentReceived && t.ticketType === "ticket"
  );

  for (const ticket of openTickets) {
    try {
      const result = await getIncomingTransactions(
        ticket.walletAddress,
        lastSeenSig[ticket.walletAddress]
      );
      if (!result) continue;

      lastSeenSig[ticket.walletAddress] = result.signature;

      mutateData((d) => {
        const t = d.tickets.find((t) => t.channelId === ticket.channelId);
        if (t) t.paymentReceived = true;
      });

      const ticketChannel =
        guild.channels.cache.get(ticket.channelId) ?? null;
      const member = await guild.members.fetch(ticket.userId).catch(() => null);
      const username = member?.user.username ?? ticket.userId;

      await handlePayment(
        client,
        guild,
        ticket.userId,
        username,
        result.amount,
        "on-chain",
        ticket.walletAddress,
        ticketChannel
      );
    } catch (err) {
      console.error(`Poll error for ticket ${ticket.channelId}:`, err);
    }
  }
}
