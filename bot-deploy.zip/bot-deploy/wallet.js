import { Keypair, Connection, PublicKey, LAMPORTS_PER_SOL } from "@solana/web3.js";
import bs58 from "bs58";

export function generateWallet() {
  const keypair = Keypair.generate();
  const address = keypair.publicKey.toBase58();
  const privateKey = bs58.encode(keypair.secretKey);
  return { address, privateKey };
}

export function getConnection() {
  const rpc = process.env["SOLANA_RPC"] || "https://api.mainnet-beta.solana.com";
  return new Connection(rpc, "confirmed");
}

export async function getWalletBalance(address) {
  try {
    const connection = getConnection();
    const pubkey = new PublicKey(address);
    const lamports = await connection.getBalance(pubkey);
    return lamports / LAMPORTS_PER_SOL;
  } catch (err) {
    console.error(`Failed to get balance for ${address}:`, err);
    return 0;
  }
}

export async function getIncomingTransactions(address, afterSignature) {
  try {
    const connection = getConnection();
    const pubkey = new PublicKey(address);
    const sigs = await connection.getSignaturesForAddress(pubkey, { limit: 10 });
    if (!sigs.length) return null;

    const latest = sigs[0];
    if (!latest || (afterSignature && latest.signature === afterSignature)) return null;

    const tx = await connection.getTransaction(latest.signature, {
      maxSupportedTransactionVersion: 0,
    });
    if (!tx || !tx.meta) return null;

    const preBalances = tx.meta.preBalances;
    const postBalances = tx.meta.postBalances;
    const accountKeys =
      tx.transaction.message.staticAccountKeys ||
      tx.transaction.message.accountKeys;

    for (let i = 0; i < accountKeys.length; i++) {
      if (accountKeys[i].toBase58() === address) {
        const diff = (postBalances[i] - preBalances[i]) / LAMPORTS_PER_SOL;
        if (diff > 0) {
          return { amount: diff, signature: latest.signature };
        }
      }
    }
    return null;
  } catch (err) {
    console.error(`Failed to get transactions for ${address}:`, err);
    return null;
  }
}
