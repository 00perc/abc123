import {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  AttachmentBuilder,
} from "discord.js";
import QRCode from "qrcode";
import { getData, mutateData } from "./data.js";
import { buildProgressBar } from "./pool.js";
import {
  CHANNEL_INVEST_LOG,
  CHANNEL_PUBLIC_INVEST,
  CHANNEL_POOL_PING,
  ROLE_0_5_SOL,
  ROLE_5_PLUS_SOL,
  THUMBNAIL_URL,
} from "./constants.js";

export async function handlePayment(
  client,
  guild,
  userId,
  username,
  amount,
  method,
  walletAddress,
  ticketChannel
) {
  const data = getData();

  const userRecord = data.users[userId] ?? {
    lifetimeTotal: 0,
    roleId: null,
    investmentCount: 0,
  };
  const newTotal = userRecord.lifetimeTotal + amount;
  const roleId = newTotal >= 5 ? ROLE_5_PLUS_SOL : ROLE_0_5_SOL;

  mutateData((d) => {
    d.users[userId] = {
      lifetimeTotal: newTotal,
      roleId,
      investmentCount: (userRecord.investmentCount ?? 0) + 1,
    };
    d.investments.push({
      userId,
      username,
      amount,
      lifetimeTotal: newTotal,
      timestamp: Date.now(),
      method,
      walletAddress,
    });

    if (d.pool) {
      d.pool.current += amount;
      const existing = d.pool.contributors.find((c) => c.userId === userId);
      if (existing) {
        existing.amount += amount;
      } else {
        d.pool.contributors.push({ userId, username, amount });
      }
    }
  });

  try {
    const member = await guild.members.fetch(userId).catch(() => null);
    if (member) await assignRole(member, roleId);
  } catch (err) {
    console.error("Failed to assign role:", err);
  }

  const privateLogChannel = guild.channels.cache.get(CHANNEL_INVEST_LOG);
  if (privateLogChannel) {
    const logEmbed = new EmbedBuilder()
      .setColor(0x2b2d31)
      .setTitle("Investment Recorded")
      .addFields(
        { name: "User", value: `${username} (<@${userId}>)`, inline: true },
        { name: "User ID", value: userId, inline: true },
        { name: "Wallet", value: method === "manual" ? "Manual Credit" : walletAddress, inline: false },
        { name: "Amount", value: `${amount} SOL`, inline: true },
        { name: "Lifetime Total", value: `${newTotal.toFixed(4)} SOL`, inline: true },
        { name: "Role Assigned", value: `<@&${roleId}>`, inline: true },
        { name: "Method", value: method === "on-chain" ? "On-Chain" : "Manual Credit", inline: true },
        { name: "Timestamp", value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
      )
      .setTimestamp();
    await privateLogChannel.send({ embeds: [logEmbed] }).catch(console.error);
  }

  let displayName = null;

  if (ticketChannel) {
    try {
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`show_name_${userId}`)
          .setLabel("Show My Name")
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId(`stay_anon_${userId}`)
          .setLabel("Stay Anonymous")
          .setStyle(ButtonStyle.Secondary)
      );
      const prompt = await ticketChannel.send({
        content: `<@${userId}> Your payment has been received! Would you like to be shown publicly?`,
        components: [row],
      });
      displayName = await waitForNameChoice(prompt, userId, username);
    } catch (err) {
      console.error("Name choice error:", err);
    }
  } else {
    try {
      const member = await guild.members.fetch(userId).catch(() => null);
      if (member) {
        const dm = await member.createDM();
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`show_name_${userId}`)
            .setLabel("Show My Name")
            .setStyle(ButtonStyle.Primary),
          new ButtonBuilder()
            .setCustomId(`stay_anon_${userId}`)
            .setLabel("Stay Anonymous")
            .setStyle(ButtonStyle.Secondary)
        );
        const prompt = await dm.send({
          content: `Your balance of ${amount} SOL has been added! Would you like to be shown publicly?`,
          components: [row],
        });
        displayName = await waitForNameChoice(prompt, userId, username);
      }
    } catch (err) {
      console.error("DM name choice error:", err);
    }
  }

  const sender = displayName ?? "Anonymous";
  const freshData = getData();
  const poolText = freshData.pool
    ? buildProgressBar(freshData.pool.current, freshData.pool.target)
    : "No active pool";

  const publicChannel = guild.channels.cache.get(CHANNEL_PUBLIC_INVEST);
  if (publicChannel) {
    const publicEmbed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle("Solana Investment Completed")
      .setThumbnail(THUMBNAIL_URL)
      .addFields(
        { name: "Amount", value: `${amount} SOL`, inline: true },
        { name: "Sender", value: sender, inline: true },
        { name: "Pool Progress", value: poolText, inline: false }
      )
      .setTimestamp();
    await publicChannel.send({ embeds: [publicEmbed] }).catch(console.error);
  }

  if (freshData.pool && freshData.pool.current >= freshData.pool.target) {
    const pool = freshData.pool;
    mutateData((d) => {
      if (d.pool) {
        d.poolHistory.push({ ...d.pool, endTime: Date.now() });
        d.pool = null;
      }
    });

    const pingChannel = guild.channels.cache.get(CHANNEL_POOL_PING);
    if (pingChannel) {
      const celebEmbed = new EmbedBuilder()
        .setColor(0xffd700)
        .setTitle("🎉 Pool Filled!")
        .addFields(
          { name: "Total Raised", value: `${pool.current.toFixed(4)} SOL`, inline: true },
          { name: "Investors", value: `${pool.contributors.length}`, inline: true }
        )
        .setTimestamp();
      await pingChannel.send({ content: "@everyone", embeds: [celebEmbed] }).catch(console.error);
    }
  }

  try {
    const member = await guild.members.fetch(userId).catch(() => null);
    if (member) {
      const dm = await member.createDM();
      const confirmEmbed = new EmbedBuilder()
        .setColor(0x57f287)
        .setTitle("Investment Confirmed ✅")
        .addFields(
          { name: "Amount Received", value: `${amount} SOL`, inline: true },
          { name: "Lifetime Total", value: `${newTotal.toFixed(4)} SOL`, inline: true },
          { name: "Current Role", value: `<@&${roleId}>`, inline: true }
        )
        .setDescription("Thank you for your investment! We appreciate your continued support.")
        .setTimestamp();
      await dm.send({ embeds: [confirmEmbed] }).catch(() => {});
    }
  } catch (err) {
    console.error("Failed to DM user confirmation:", err);
  }
}

async function waitForNameChoice(prompt, userId, username) {
  return new Promise((resolve) => {
    const timeout = setTimeout(async () => {
      try { await prompt.edit({ components: [] }); } catch {}
      resolve(null);
    }, 10_000);

    const collector = prompt.createMessageComponentCollector({
      filter: (i) =>
        i.user.id === userId &&
        (i.customId === `show_name_${userId}` || i.customId === `stay_anon_${userId}`),
      max: 1,
      time: 10_000,
    });

    collector.on("collect", async (interaction) => {
      clearTimeout(timeout);
      try {
        await interaction.deferUpdate();
        await prompt.edit({ components: [] });
      } catch {}
      resolve(interaction.customId === `show_name_${userId}` ? username : null);
    });

    collector.on("end", (collected) => {
      if (collected.size === 0) {
        clearTimeout(timeout);
        resolve(null);
      }
    });
  });
}

async function assignRole(member, roleId) {
  const removeId = roleId === ROLE_5_PLUS_SOL ? ROLE_0_5_SOL : null;
  if (removeId && member.roles.cache.has(removeId)) {
    await member.roles.remove(removeId).catch(console.error);
  }
  if (!member.roles.cache.has(roleId)) {
    await member.roles.add(roleId).catch(console.error);
  }
}

export async function generateQRAttachment(address) {
  const buffer = await QRCode.toBuffer(address, { type: "png", width: 300 });
  return new AttachmentBuilder(buffer, { name: "wallet-qr.png" });
}
