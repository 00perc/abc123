import {
  EmbedBuilder,
  PermissionFlagsBits,
  ChannelType,
  AttachmentBuilder,
} from "discord.js";
import { getData, mutateData } from "./data.js";
import { generateWallet } from "./wallet.js";
import { generateQRAttachment } from "./payments.js";
import {
  CATEGORY_TICKETS,
  CHANNEL_ADMIN_KEYS,
  CHANNEL_INVEST_LOG,
  TICKET_EXPIRE_MS,
} from "./constants.js";

export async function createTicket(client, guild, userId, username, ticketType) {
  const data = getData();

  // Each type is tracked independently — one investment ticket + one support ticket allowed at once
  const existing = data.tickets.find(
    (t) => t.userId === userId && t.status === "open" && t.ticketType === ticketType
  );
  if (existing) {
    // Verify the channel still actually exists on Discord (admin may have deleted it)
    const existingChannel = await guild.channels.fetch(existing.channelId).catch(() => null);
    if (existingChannel) {
      return { channel: existingChannel, alreadyExists: true };
    }
    // Channel was deleted externally — mark it closed and let them open a new one
    mutateData((d) => {
      const t = d.tickets.find((t) => t.channelId === existing.channelId);
      if (t) t.status = "closed";
    });
  }

  const category = guild.channels.cache.get(CATEGORY_TICKETS) ?? null;
  const now = Date.now();

  const safeName = username.toLowerCase().replace(/[^a-z0-9]/g, "");
  const channelName = ticketType === "ticket" ? `invest-${safeName}` : `support-${safeName}`;

  const channel = await guild.channels.create({
    name: channelName,
    type: ChannelType.GuildText,
    parent: category,
    permissionOverwrites: [
      {
        id: guild.roles.everyone,
        deny: [PermissionFlagsBits.ViewChannel],
      },
      {
        id: userId,
        allow: [
          PermissionFlagsBits.ViewChannel,
          PermissionFlagsBits.SendMessages,
          PermissionFlagsBits.ReadMessageHistory,
        ],
      },
      {
        id: guild.members.me.id,
        allow: [
          PermissionFlagsBits.ViewChannel,
          PermissionFlagsBits.SendMessages,
          PermissionFlagsBits.ManageChannels,
          PermissionFlagsBits.ReadMessageHistory,
        ],
      },
    ],
  });

  if (ticketType === "support") {
    // Support ticket — no wallet, just a welcome message
    mutateData((d) => {
      d.tickets.push({
        userId,
        channelId: channel.id,
        walletAddress: null,
        privateKey: null,
        createdAt: now,
        status: "open",
        paymentReceived: false,
        ticketType,
      });
    });

    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle(`Support Ticket — ${username}`)
      .setDescription("Support will be with you shortly. Please describe your issue and a team member will assist you.")
      .setTimestamp();

    await channel.send({ embeds: [embed] });
    scheduleTicketExpiry(client, guild, userId, channel.id, now);
    return { channel, alreadyExists: false };
  }

  // Investment ticket — generate wallet and QR
  const wallet = generateWallet();

  mutateData((d) => {
    d.tickets.push({
      userId,
      channelId: channel.id,
      walletAddress: wallet.address,
      privateKey: wallet.privateKey,
      createdAt: now,
      status: "open",
      paymentReceived: false,
      ticketType,
    });
  });

  const qrAttachment = await generateQRAttachment(wallet.address).catch(() => null);

  const embed = new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle(`Investment Ticket — ${username}`)
    .setDescription("Send SOL to the wallet address below to invest. Your deposit will be detected automatically within 30 seconds.")
    .addFields(
      { name: "Wallet Address", value: `\`${wallet.address}\``, inline: false },
      {
        name: "Instructions",
        value:
          "1. Copy the wallet address above\n2. Send your SOL investment\n3. Wait for automatic confirmation\n4. Ticket expires in 24 hours if no payment received",
      }
    )
    .setTimestamp();

  const files = qrAttachment ? [qrAttachment] : [];
  await channel.send({ embeds: [embed], files });

  const adminChannel = guild.channels.cache.get(CHANNEL_ADMIN_KEYS);
  if (adminChannel) {
    const adminEmbed = new EmbedBuilder()
      .setColor(0xed4245)
      .setTitle("🔑 New Ticket Wallet (Private Recovery)")
      .addFields(
        { name: "User", value: `${username} (<@${userId}>)`, inline: true },
        { name: "Ticket Channel", value: `<#${channel.id}>`, inline: true },
        { name: "Wallet Address", value: `\`${wallet.address}\``, inline: false },
        { name: "Private Key", value: `\`${wallet.privateKey}\``, inline: false }
      )
      .setTimestamp();
    await adminChannel.send({ embeds: [adminEmbed] }).catch(console.error);
  }

  scheduleTicketExpiry(client, guild, userId, channel.id, now);

  return { channel, alreadyExists: false };
}

function scheduleTicketExpiry(client, guild, userId, channelId, createdAt) {
  const remaining = TICKET_EXPIRE_MS - (Date.now() - createdAt);
  if (remaining <= 0) {
    expireTicket(client, guild, userId, channelId).catch(console.error);
    return;
  }
  setTimeout(() => {
    const data = getData();
    const ticket = data.tickets.find((t) => t.channelId === channelId && t.status === "open");
    if (ticket && !ticket.paymentReceived) {
      expireTicket(client, guild, userId, channelId).catch(console.error);
    }
  }, remaining);
}

export async function expireTicket(client, guild, userId, channelId) {
  const data = getData();
  const ticket = data.tickets.find((t) => t.channelId === channelId);
  if (!ticket || ticket.status !== "open") return;

  mutateData((d) => {
    const t = d.tickets.find((t) => t.channelId === channelId);
    if (t) t.status = "expired";
  });

  const channel = guild.channels.cache.get(channelId) ?? null;
  if (channel) {
    await sendTranscript(guild, channel).catch(console.error);
    await channel.delete("Ticket expired (no payment in 24h)").catch(console.error);
  }

  try {
    const member = await guild.members.fetch(userId).catch(() => null);
    if (member) {
      const dm = await member.createDM();
      await dm.send({
        embeds: [
          new EmbedBuilder()
            .setColor(0xed4245)
            .setTitle("Ticket Expired")
            .setDescription(
              "Your investment ticket has expired because no payment was detected within 24 hours. Please create a new ticket."
            )
            .setTimestamp(),
        ],
      });
    }
  } catch (err) {
    console.error("Failed to DM expired ticket user:", err);
  }
}

export async function closeTicket(client, guild, channel) {
  mutateData((d) => {
    const t = d.tickets.find((t) => t.channelId === channel.id);
    if (t && t.status === "open") t.status = "closed";
  });

  await sendTranscript(guild, channel).catch(console.error);
  await channel.delete("Ticket closed by admin").catch(console.error);
}

async function sendTranscript(guild, channel) {
  try {
    const messages = await channel.messages.fetch({ limit: 100 });
    const sorted = [...messages.values()].sort((a, b) => a.createdTimestamp - b.createdTimestamp);

    const lines = sorted.map((m) => {
      const time = new Date(m.createdTimestamp).toISOString();
      const content = m.content || (m.embeds.length ? "[embed]" : "[attachment]");
      return `[${time}] ${m.author.tag}: ${content}`;
    });

    const transcript = lines.join("\n") || "(no messages)";
    const attachment = new AttachmentBuilder(Buffer.from(transcript, "utf-8"), {
      name: `transcript-${channel.name}.txt`,
    });

    const logChannel = guild.channels.cache.get(CHANNEL_INVEST_LOG);
    if (logChannel) {
      const embed = new EmbedBuilder()
        .setColor(0x2b2d31)
        .setTitle("Ticket Transcript")
        .addFields(
          { name: "Channel", value: `#${channel.name}`, inline: true },
          { name: "Closed At", value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
        );
      await logChannel.send({ embeds: [embed], files: [attachment] });
    }
  } catch (err) {
    console.error("Failed to send transcript:", err);
  }
}

export function restoreTicketTimers(client, guild) {
  const data = getData();
  const openTickets = data.tickets.filter((t) => t.status === "open");
  for (const ticket of openTickets) {
    scheduleTicketExpiry(client, guild, ticket.userId, ticket.channelId, ticket.createdAt);
  }
}
