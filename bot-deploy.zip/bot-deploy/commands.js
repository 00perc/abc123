import {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
} from "discord.js";
import { getData, mutateData } from "./data.js";
import { handlePayment } from "./payments.js";
import { buildProgressBar } from "./pool.js";
import { closeTicket } from "./tickets.js";

export const commandDefinitions = [
  new SlashCommandBuilder()
    .setName("startpool")
    .setDescription("Start a new investment pool (Admin only)")
    .addNumberOption((o) =>
      o.setName("target").setDescription("SOL target for the pool").setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  new SlashCommandBuilder()
    .setName("addbalance")
    .setDescription("Manually credit a user with SOL (Admin only)")
    .addUserOption((o) =>
      o.setName("user").setDescription("The Discord user to credit").setRequired(true)
    )
    .addNumberOption((o) =>
      o.setName("amount").setDescription("Amount of SOL to credit").setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  new SlashCommandBuilder()
    .setName("investments")
    .setDescription("View all investment statistics (Admin only)")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  new SlashCommandBuilder()
    .setName("poolstatus")
    .setDescription("View current pool status (Admin only)")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  new SlashCommandBuilder()
    .setName("closeticket")
    .setDescription("Force close the current ticket channel (Admin only)")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
].map((c) => c.toJSON());

export async function handleCommand(interaction, client, guild) {
  const { commandName } = interaction;

  if (commandName === "startpool") {
    const target = interaction.options.getNumber("target", true);
    const data = getData();
    if (data.pool?.active) {
      await interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0xed4245)
            .setDescription("A pool is already active. Complete or cancel it first."),
        ],
        ephemeral: true,
      });
      return;
    }
    mutateData((d) => {
      d.pool = {
        target,
        current: 0,
        contributors: [],
        startTime: Date.now(),
        active: true,
      };
    });
    await interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(0x57f287)
          .setTitle("Pool Started")
          .addFields(
            { name: "Target", value: `${target} SOL`, inline: true },
            { name: "Progress", value: buildProgressBar(0, target), inline: false }
          )
          .setTimestamp(),
      ],
      ephemeral: true,
    });
    return;
  }

  if (commandName === "addbalance") {
    const user = interaction.options.getUser("user", true);
    const amount = interaction.options.getNumber("amount", true);
    await interaction.deferReply({ ephemeral: true });

    await handlePayment(client, guild, user.id, user.username, amount, "manual", "Manual Credit", null);

    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(0x57f287)
          .setTitle("Balance Added")
          .addFields(
            { name: "User", value: `<@${user.id}>`, inline: true },
            { name: "Amount", value: `${amount} SOL`, inline: true }
          )
          .setTimestamp(),
      ],
    });
    return;
  }

  if (commandName === "investments") {
    const data = getData();
    const totalTickets = data.tickets.length;
    const totalInvestments = data.investments.length;
    const totalSOL = data.investments.reduce((sum, inv) => sum + inv.amount, 0);

    const investorLines =
      Object.entries(data.users)
        .map(([uid, u]) => {
          const invs = data.investments.filter((i) => i.userId === uid);
          const realCount = invs.filter((i) => i.method === "on-chain").length;
          const manualCount = invs.filter((i) => i.method === "manual").length;
          return `<@${uid}> — ${u.lifetimeTotal.toFixed(4)} SOL (${u.investmentCount} invs, ${realCount} on-chain, ${manualCount} manual) <@&${u.roleId ?? "none"}>`;
        })
        .join("\n") || "No investors yet";

    const poolText = data.pool
      ? `Active — ${buildProgressBar(data.pool.current, data.pool.target)}`
      : "No active pool";

    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle("Investment Statistics")
      .addFields(
        { name: "Total Tickets", value: `${totalTickets}`, inline: true },
        { name: "Total Investments", value: `${totalInvestments}`, inline: true },
        { name: "Total SOL Invested", value: `${totalSOL.toFixed(4)} SOL`, inline: true },
        { name: "Pool Status", value: poolText, inline: false },
        { name: "Investors", value: investorLines.slice(0, 1000), inline: false }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }

  if (commandName === "poolstatus") {
    const data = getData();
    if (!data.pool) {
      await interaction.reply({
        embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("No active pool.")],
        ephemeral: true,
      });
      return;
    }

    const { pool } = data;
    const contribLines =
      pool.contributors.map((c) => `<@${c.userId}> — ${c.amount.toFixed(4)} SOL`).join("\n") ||
      "No contributors yet";

    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle("Pool Status")
      .addFields(
        { name: "Target", value: `${pool.target} SOL`, inline: true },
        { name: "Current", value: `${pool.current.toFixed(4)} SOL`, inline: true },
        { name: "Progress", value: buildProgressBar(pool.current, pool.target), inline: false },
        { name: "Contributors", value: `${pool.contributors.length}`, inline: true },
        { name: "Started", value: `<t:${Math.floor(pool.startTime / 1000)}:F>`, inline: true },
        { name: "Contributor List", value: contribLines.slice(0, 1000), inline: false }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }

  if (commandName === "closeticket") {
    const channel = interaction.channel;
    if (!channel) {
      await interaction.reply({
        embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("Must be used inside a ticket channel.")],
        ephemeral: true,
      });
      return;
    }

    const data = getData();
    const ticket = data.tickets.find((t) => t.channelId === channel.id && t.status === "open");
    if (!ticket) {
      await interaction.reply({
        embeds: [new EmbedBuilder().setColor(0xed4245).setDescription("This channel is not an open ticket.")],
        ephemeral: true,
      });
      return;
    }

    await interaction.reply({
      embeds: [new EmbedBuilder().setColor(0xfee75c).setDescription("Closing ticket and generating transcript...")],
      ephemeral: true,
    });

    await closeTicket(client, guild, channel);
    return;
  }
}
