export function buildProgressBar(current, target) {
  const pct = Math.min(current / target, 1);
  const filled = Math.round(pct * 20);
  const empty = 20 - filled;
  const bar = "█".repeat(filled) + "░".repeat(empty);
  const pctDisplay = Math.round(pct * 100);
  return `[${bar}] ${current.toFixed(2)}/${target} SOL (${pctDisplay}%)`;
}
